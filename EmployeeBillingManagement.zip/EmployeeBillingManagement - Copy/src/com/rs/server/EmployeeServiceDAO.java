package com.rs.server;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.spring.dao.CityDetails;
import com.spring.dao.CityDetailsJDBCTemplate;
import com.spring.dao.LoginDetails;
import com.spring.dao.LoginDetailsJDBCTemplate;

public class EmployeeServiceDAO {
	ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");

	LoginDetailsJDBCTemplate loginDetailsJDBCTemplate = 
      (LoginDetailsJDBCTemplate)context.getBean("loginDetailsJDBCTemplate");
	
	CityDetailsJDBCTemplate cityDetailsJDBCTemplate = 
		      (CityDetailsJDBCTemplate)context.getBean("cityDetailsJDBCTemplate");
	
	public LoginDetails getLoginDetails(String userid)
	{
	return loginDetailsJDBCTemplate.getLoginDetails(userid);
	};
	
	public CityDetails getCityDetails()
	{
	return cityDetailsJDBCTemplate.getCityDetails("Bangalore");
	};
	
	public void updateLoginDetails(LoginDetails user)
	{
		loginDetailsJDBCTemplate.update(user.getUserid(), user.getPwd());
	};
	
}
