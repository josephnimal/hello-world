package com.spring.dao;

import javax.sql.DataSource;

public interface CityDetailsDAO {
	public void setDataSource(DataSource ds);
	public CityDetails getCityDetails(String city);
	public void update(String city, int workingdays0, int workingdays1, int workingdays2, int workingdays3, int workingdays4);
}
