package com.spring.dao;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class LoginDetails{

	private String userid;
	private String pwd;
	private boolean admin;
	
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public boolean isAdmin() {
		return admin;
	}
	public void setAdmin(boolean admin) {
		this.admin = admin;
	}
	

}
