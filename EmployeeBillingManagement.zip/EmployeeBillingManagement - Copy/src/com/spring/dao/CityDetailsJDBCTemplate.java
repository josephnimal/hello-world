package com.spring.dao;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

public class CityDetailsJDBCTemplate implements CityDetailsDAO{
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplateObject;
	
	@Override
	public void setDataSource(DataSource ds) {
		this.dataSource = ds;
	    this.jdbcTemplateObject = new JdbcTemplate(ds);
	}

	@Override
	public CityDetails getCityDetails(String city) {
		String SQL = "select * from CityDetails where city = ?";
		CityDetails cityDetails = jdbcTemplateObject.queryForObject(SQL,new Object[]{city}, new CityDetailsMapper());
	    return cityDetails;
	}

	@Override
	public void update(String city, int workingdays0, int workingdays1,
			int workingdays2, int workingdays3, int workingdays4) {
		String SQL = "update CityDetails set workdayscount0 = ?, workdayscount1 = ?, workdayscount2 =?, workdayscount3 = ?, workdayscount4 = ? where city = ?";
	    jdbcTemplateObject.update(SQL, workingdays0, workingdays1,workingdays2, workingdays3, workingdays4, city);
	    System.out.println("Updated Record with city = " + city );
	    return;
	}

}
