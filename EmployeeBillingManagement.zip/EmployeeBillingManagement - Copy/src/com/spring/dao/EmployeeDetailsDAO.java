package com.spring.dao;

import javax.sql.DataSource;

public interface EmployeeDetailsDAO {
	public void setDataSource(DataSource ds);
	public EmployeeDetails getEmployeeDetails(int empid);
	public void insert(String userid, int empId, String empName, String billingRole, String infosysRole, int leaveCount0, int leaveCount1, int leaveCount2, int leaveCount3, int leaveCount4, String DU, String city, boolean leaveCodeAlloc);
	public void update(String userid, int empId, String empName, String billingRole, String infosysRole, int leaveCount0, int leaveCount1, int leaveCount2, int leaveCount3, int leaveCount4, String DU, String city, boolean leaveCodeAlloc);
}