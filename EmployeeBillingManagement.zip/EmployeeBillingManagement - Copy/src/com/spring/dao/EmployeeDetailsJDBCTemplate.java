package com.spring.dao;

import javax.sql.DataSource;

import org.springframework.jdbc.core.JdbcTemplate;

public class EmployeeDetailsJDBCTemplate implements EmployeeDetailsDAO{
	private DataSource dataSource;
	private JdbcTemplate jdbcTemplateObject;
	
	@Override
	public void setDataSource(DataSource ds) {
		this.dataSource = ds;
	    this.jdbcTemplateObject = new JdbcTemplate(ds);
	}

	@Override
	public EmployeeDetails getEmployeeDetails(int empid) {
		String SQL = "select * from EmployeeDetails where empid = ?";
		EmployeeDetails empDetails = jdbcTemplateObject.queryForObject(SQL,new Object[]{empid}, new EmployeeDetailsMapper());
	    return empDetails;
	}

	@Override
	public void update(String userid, int empId, String empName,
			String billingRole, String infosysRole, int leaveCount0,
			int leaveCount1, int leaveCount2, int leaveCount3, int leaveCount4,
			String DU, String city, boolean leaveCodeAlloc) {
		String SQL = "update EmployeeDetails set empid = ?, empname = ?, billingrole = ?, infosysrole = ?, leavecount0 = ?, leavecount1 = ?, leavecount2 = ?, leavecount3 = ?, leavecount4 = ?, DU = ?, city = ?, leavecodealloc = ? where userid = ?";
	    jdbcTemplateObject.update(SQL, empId, empName, billingRole,infosysRole,leaveCount0,leaveCount1,leaveCount2,leaveCount3,leaveCount4,DU,city,leaveCodeAlloc,userid);
	    System.out.println("Updated Record with USERID = " + userid );
	    return;
	}

	@Override
	public void insert(String userid, int empId, String empName,
			String billingRole, String infosysRole, int leaveCount0,
			int leaveCount1, int leaveCount2, int leaveCount3, int leaveCount4,
			String DU, String city, boolean leaveCodeAlloc) {
		String SQL = "insert into EmployeeDetails values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	    jdbcTemplateObject.update( SQL, userid, empId, empName, billingRole, infosysRole, leaveCount0, leaveCount1, leaveCount2, leaveCount3, leaveCount4, DU, city, leaveCodeAlloc);
	    System.out.println("Created Record Name = " + empName + " user id = " + userid);
	    return;
	}

}
