package com.spring.dao;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");

		LoginDetailsJDBCTemplate loginDetailsJDBCTemplate = 
	      (LoginDetailsJDBCTemplate)context.getBean("loginDetailsJDBCTemplate");
		
		EmployeeDetailsJDBCTemplate employeeDetailsJDBCTemplate = 
			      (EmployeeDetailsJDBCTemplate)context.getBean("employeeDetailsJDBCTemplate");
		
		CityDetailsJDBCTemplate cityDetailsJDBCTemplate = 
			      (CityDetailsJDBCTemplate)context.getBean("cityDetailsJDBCTemplate");
		
		System.out.println(loginDetailsJDBCTemplate.getLoginDetails("josephnimal").getPwd());
		loginDetailsJDBCTemplate.update("shrutiverma", "321654");
		System.out.println(loginDetailsJDBCTemplate.getLoginDetails("shrutiverma").getPwd());
		
		//employeeDetailsJDBCTemplate.insert("josephnimal", 665156, "Joseph Nimal Fernando", "Developer", "Systems Engineer", 0, 1, 1, 0, 0, "Bangalore", "Bangalore", true);
		employeeDetailsJDBCTemplate.update("josephnimal", 665156, "Joseph Nimal Fernando", "Developer", "Systems Engineer", 0, 1, 3, 2, 2, "Bangalore", "Bangalore", true);
		System.out.println(employeeDetailsJDBCTemplate.getEmployeeDetails(665156).getLeaveCount2());
		
		cityDetailsJDBCTemplate.update("Bangalore", 20, 24, 23, 22, 22);
		System.out.println(cityDetailsJDBCTemplate.getCityDetails("Bangalore").getWorkingDays0());
		
		
	}

}
