package com.spring.rest;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.spring.dao.LoginDetails;
import com.spring.dao.LoginDetailsJDBCTemplate;

@RestController
public class BillingController {
	@RequestMapping(value = "/login", method = RequestMethod.GET,headers="Accept=application/json")
	public LoginDetails getLoginDeatils()
	{
		LoginDetailsJDBCTemplate userdetails = new LoginDetailsJDBCTemplate();
		return userdetails.getLoginDetails("josephnimal");
	}
}
