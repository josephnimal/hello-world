package com.spring.dao;

public class CityDetails {
	private String city;
	private int workDaysCount0;
	private int workDaysCount1;
	private int workDaysCount2;
	private int workDaysCount3;
	private int workDaysCount4;
	
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getWorkingDays0() {
		return workDaysCount0;
	}
	public void setWorkingDays0(int workingDays0) {
		this.workDaysCount0 = workingDays0;
	}
	public int getWorkingDays1() {
		return workDaysCount1;
	}
	public void setWorkingDays1(int workingDays1) {
		this.workDaysCount1 = workingDays1;
	}
	public int getWorkingDays2() {
		return workDaysCount2;
	}
	public void setWorkingDays2(int workingDays2) {
		this.workDaysCount2 = workingDays2;
	}
	public int getWorkingDays3() {
		return workDaysCount3;
	}
	public void setWorkingDays3(int workingDays3) {
		this.workDaysCount3 = workingDays3;
	}
	public int getWorkingDays4() {
		return workDaysCount4;
	}
	public void setWorkingDays4(int workingDays4) {
		this.workDaysCount4 = workingDays4;
	}
	
}
