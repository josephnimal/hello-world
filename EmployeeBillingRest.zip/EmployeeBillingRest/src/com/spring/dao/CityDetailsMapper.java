package com.spring.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

public class CityDetailsMapper implements RowMapper<CityDetails> {
	   public CityDetails mapRow(ResultSet rs, int rowNum) throws SQLException {
		   	  CityDetails cityDetails = new CityDetails();
		   	  cityDetails.setCity(rs.getString("city"));
		   	  cityDetails.setWorkingDays0(rs.getInt("workDaysCount0"));
		      cityDetails.setWorkingDays1(rs.getInt("workDaysCount1"));
		   	  cityDetails.setWorkingDays2(rs.getInt("workDaysCount2"));
		   	  cityDetails.setWorkingDays3(rs.getInt("workDaysCount3"));
		   	  cityDetails.setWorkingDays4(rs.getInt("workDaysCount4"));
		      return cityDetails;
		   }
		}